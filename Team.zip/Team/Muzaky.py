def perkenalan(nama, nim, peran):
    print("Halo! Perkenalkan, nama saya", nama)
    print("NIM : ", nim)
    print("Peran saya yaitu : ", peran)

if __name__ == "__main__":
    nama = "Muzaki Syifauz Z.A "
    nim = "2213010422"
    peran = "Mengerjakan Forms dan database"
    perkenalan(nama, nim, peran)