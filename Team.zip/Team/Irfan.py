def perkenalan(nama, nim, peran):
    print("Halo! Perkenalkan, nama saya", nama)
    print("NIM : ", nim)
    print("Peran saya yaitu : ", peran)

if __name__ == "__main__":
    nama = "Irfan Maulana"
    nim = "2213010414"
    peran = "Mengerjakan Bagian models dan static sebagian dari template"
    perkenalan(nama, nim, peran)