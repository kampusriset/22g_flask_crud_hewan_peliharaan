def perkenalan(nama, nim, peran):
    print("Halo! Perkenalkan, nama saya", nama)
    print("NIM : ", nim)
    print("Peran saya yaitu : ", peran)

if __name__ == "__main__":
    nama = "Peniel Manurung"
    nim = "2213010420"
    peran = "Mengerjakan templates"
    perkenalan(nama, nim, peran)